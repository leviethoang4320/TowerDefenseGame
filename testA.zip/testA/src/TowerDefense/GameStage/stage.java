package TowerDefense.GameStage;

import javax.swing.*;
import java.awt.*;

public class stage extends JPanel {
    Image image,image1 ;
    public stage(){
        ImageIcon imageIcon = new ImageIcon("image/stage.jpg");
        image = imageIcon.getImage();
        /*ImageIcon imageIcon1 = new ImageIcon("image/play.png");
        image1 = imageIcon1.getImage();*/
    }
    public void paint(Graphics g){
        g.drawImage(image,0,0,null);
        //g.drawImage(image1,500,300,this);
    }


}
