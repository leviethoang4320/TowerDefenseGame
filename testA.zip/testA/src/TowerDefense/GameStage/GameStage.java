package TowerDefense.GameStage;

import TowerDefense.Solution.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameStage extends JFrame {
    stage stage = new stage();

    public GameStage(){
        add(stage);
        setSize(1116,639);
        setTitle(" TOWER DEFENSE ");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(150,0);

        ImageIcon imageIcon1 = new ImageIcon("image/play.png");
        JButton play = new JButton(imageIcon1);
        //play.setVisible(false);
        add(play);
        play.setBounds(500,300,100,100);
        play.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                Main m = new Main();
            }
        });


    }

    public static void main(String[] args){
        GameStage g = new GameStage();
    }
}
