package TowerDefense.Solution;

import TowerDefense.GameStage.GameStage;

import javax.swing.*;

public class Main extends JFrame {
    GameField gameField = new GameField();
    GameStage gameStage = new GameStage();
    public Main(){
        setSize(1116,639);
        setTitle(" TOWER DEFENSE ");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(150,0);
        add(gameField);
    }
}
