package TowerDefense.Solution;

import TowerDefense.Bullet.Bullet;
import TowerDefense.Bullet.Bullet1;
import TowerDefense.Bullet.Bullet2;
import TowerDefense.Enemy.Enemy;
import TowerDefense.Enemy.Enemy1;
import TowerDefense.Enemy.EnemyBoss;
import TowerDefense.Tile.Tile;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Impact {
    List<Enemy> enemies = new ArrayList<Enemy>();
    List<Bullet> bullets = new ArrayList<Bullet>();
    List<Bullet1> bullets1;
    List<Bullet2> bullets2;
    List<Enemy1> enemies1 = new ArrayList<Enemy1>();
    List<EnemyBoss> bosses = new ArrayList<>() ;
    int knockEnemy =0 ;
    Tile tile = new Tile();
    boolean win = false;

    public boolean isWin() {
        return win;
    }

    public int getKnockEnemy() {
        return knockEnemy;
    }
    public void setKnockEnemy(int knockEnemy){
        this.knockEnemy = knockEnemy;
    }

    public Impact(List<Enemy> enemies, List<Enemy1> enemies1,List<EnemyBoss> bosses, List<Bullet> bullets,List<Bullet1> bullets1,List<Bullet2> bullets2, Tile tile) {
        this.enemies = enemies;
        this.enemies1 = enemies1;
        this.bosses = bosses;
        this.bullets = bullets;
        this.bullets1 = bullets1;
        this.tile = tile;
        this.bullets2 = bullets2;
    }


    public void checkImpact(){
         {
            for (int i = 0; i < bullets.size(); i++) {
                Bullet bullet = bullets.get(i);
                int x = bullet.getX1();
                int y = bullet.getY1();
                for (int j = 0; j < enemies.size(); j++) {
                    Enemy enemy = enemies.get(j);
                    int xx = enemy.getX();
                    int yy = enemy.getY();
                    if (new Rectangle(x, y, 10, 10).intersects(new Rectangle(xx, yy, 30, 30))) {
                        enemy.setHp(enemy.getHp() - bullet.getDAMAGE());
                        if(i<bullets.size())
                        bullets.remove(i);

                        if (enemy.getHp() <= 0) {
                            enemies.remove(j);
                            knockEnemy++;
                            tile.setCoin(tile.getCoin() + 10);
                            tile.setScore(tile.getScore() + 10);
                        }
                    }
                }
                for (int j = 0; j < enemies1.size(); j++) {
                    Enemy1 enemy1 = enemies1.get(j);
                    int xx = enemy1.getX();
                    int yy = enemy1.getY();
                    if (new Rectangle(x, y, 10, 10).intersects(new Rectangle(xx, yy, 40, 40))) {
                        if(i<bullets.size())
                        bullets.remove(i);
                        enemy1.setHp(enemy1.getHp() - bullet.getDAMAGE());
                        if (enemy1.getHp() <= 0) {
                            enemies1.remove(j);
                            knockEnemy++;
                            tile.setCoin(tile.getCoin() + 20);
                            tile.setScore(tile.getScore() + 20);
                        }
                    }
                }
                if (bosses.size() > 0) {
                    knockEnemy = 0;
                    int xb = bosses.get(0).getX();
                    int yb = bosses.get(0).getY();
                    if (new Rectangle(x, y, 10, 10).intersects(new Rectangle(xb, yb, 50, 50))) {
                        if(i<bullets.size())
                        bullets.remove(i);
                        bosses.get(0).setHp(bosses.get(0).getHp() - bullet.getDAMAGE());
                        if (bosses.get(0).getHp() <= 0) {
                            bosses.remove(0);
                            knockEnemy++;
                            win = true;
                            tile.setScore(tile.getScore() + 50);
                        }
                    }
                }
            }
        }
    }
    public void checkImpact1(){
         {
            for (int i = 0; i < bullets1.size(); i++) {
                Bullet1 bullet1 = bullets1.get(i);
                int x = bullet1.getX1();
                int y = bullet1.getY1();
                for (int j = 0; j < enemies.size(); j++) {
                    Enemy enemy = enemies.get(j);
                    int xx = enemy.getX();
                    int yy = enemy.getY();
                    if (new Rectangle(x, y, 10, 10).intersects(new Rectangle(xx, yy, 30, 30))) {
                        if(i<bullets1.size())
                        bullets1.remove(i);
                        enemy.setHp(enemy.getHp() - bullet1.getDAMAGE());
                        if (enemy.getHp() <= 0) {
                            enemies.remove(j);
                            knockEnemy++;
                            tile.setCoin(tile.getCoin() + 10);
                            tile.setScore(tile.getScore() + 10);
                        }
                    }
                }
                for (int j = 0; j < enemies1.size(); j++) {
                    Enemy1 enemy1 = enemies1.get(j);
                    int xx = enemy1.getX();
                    int yy = enemy1.getY();
                    if (new Rectangle(x, y, 10, 10).intersects(new Rectangle(xx, yy, 40, 40))) {
                        if(i<bullets1.size())
                        bullets1.remove(i);
                        enemy1.setHp(enemy1.getHp() - bullet1.getDAMAGE());
                        if (enemy1.getHp() <= 0) {
                            enemies1.remove(j);
                            knockEnemy++;
                            tile.setCoin(tile.getCoin() + 20);
                            tile.setScore(tile.getScore() + 20);
                        }
                    }
                }
                if (bosses.size() > 0) {
                    int xb = bosses.get(0).getX();
                    int yb = bosses.get(0).getY();
                    if (new Rectangle(x, y, 10, 10).intersects(new Rectangle(xb, yb, 50, 50))) {
                        if(i<bullets1.size())
                        bullets1.remove(i);
                        bosses.get(0).setHp(bosses.get(0).getHp() - bullet1.getDAMAGE());
                        if (bosses.get(0).getHp() <= 0) {
                            bosses.remove(0);
                            win = true;
                            tile.setScore(tile.getScore() + 50);

                        }
                    }
                }
            }
        }
    }
    public void checkImpact2(){
         {
            for (int i = 0; i < bullets2.size() ; i++) {
                Bullet2 bullet2 = bullets2.get(i);
                int x = bullet2.getX1();
                int y = bullet2.getY1();
                for (int j = 0; j < enemies.size(); j++) {
                    Enemy enemy = enemies.get(j);
                    int xx = enemy.getX();
                    int yy = enemy.getY();
                    if (new Rectangle(x, y, 15, 15).intersects(new Rectangle(xx, yy, 30, 30))) {
                        if(i<bullets2.size())
                        bullets2.remove(i);
                        enemy.setHp(enemy.getHp() - bullet2.getDAMAGE());
                        if (enemy.getHp() <= 0) {
                            enemies.remove(j);
                            knockEnemy++;
                            tile.setCoin(tile.getCoin() + 10);
                            tile.setScore(tile.getScore() + 10);
                        }
                    }
                }
                for (int j = 0; j < enemies1.size(); j++) {
                    Enemy1 enemy1 = enemies1.get(j);
                    int xx = enemy1.getX();
                    int yy = enemy1.getY();
                    if (new Rectangle(x, y, 15, 15).intersects(new Rectangle(xx, yy, 40, 40))) {
                        if(i<bullets2.size())
                        bullets2.remove(i);
                        enemy1.setHp(enemy1.getHp() - bullet2.getDAMAGE());
                        if (enemy1.getHp() <= 0) {
                            enemies1.remove(j);
                            knockEnemy++;
                            tile.setCoin(tile.getCoin() + 20);
                            tile.setScore(tile.getScore() + 20);
                        }
                    }
                }
                if (bosses.size() > 0) {
                    int xb = bosses.get(0).getX();
                    int yb = bosses.get(0).getY();
                    if (new Rectangle(x, y, 15, 15).intersects(new Rectangle(xb, yb, 50, 50))) {
                        if(i<bullets2.size())
                        bullets2.remove(i);
                        bosses.get(0).setHp(bosses.get(0).getHp() - bullet2.getDAMAGE());
                        if (bosses.get(0).getHp() <= 0) {
                            bosses.remove(0);
                            knockEnemy++;
                            win = true;
                            tile.setScore(tile.getScore() + 50);
                        }
                    }
                }
            }
        }
    }
}
