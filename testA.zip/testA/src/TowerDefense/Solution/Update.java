package TowerDefense.Solution;

import TowerDefense.Bullet.Bullet;
import TowerDefense.Bullet.Bullet1;
import TowerDefense.Bullet.Bullet2;
import TowerDefense.Enemy.Enemy;
import TowerDefense.Enemy.Enemy1;
import TowerDefense.Enemy.EnemyBoss;
import TowerDefense.Tile.Tile;
import TowerDefense.Tower.Tower;
import TowerDefense.Tower.Tower1;
import TowerDefense.Tower.Tower2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Update {
    List<Enemy> enemies = new ArrayList<Enemy>();
    List<Bullet> bullets = new ArrayList<Bullet>();
    List<Bullet1> bullets1;
    List<Bullet2> bullets2;
    List<Enemy1> enemies1 = new ArrayList<Enemy1>();
    List<EnemyBoss> bosses;
    List<Tower> towers = new ArrayList<Tower>();
    List<Tower1> towers1;
    List<Tower2> towers2;
    Tile tile;
    int wait = 0, wait1=0,wait2=0,wait3=0;
    Random rd = new Random();
    int temp = 0;
    public int getTemp(){
        return this.temp;
    }

    public void setTemp(int temp) {
        this.temp = temp;
    }

    public Update(List<Enemy> enemies, List<Bullet> bullets, List<Bullet1> bullets1,List<Bullet2> bullets2, List<Enemy1> enemies1,List<EnemyBoss> bosses, List<Tower> towers, List<Tower1> towers1,List<Tower2> towers2, Tile tile, int wait, int wait1, int wait2) {
        this.enemies = enemies;
        this.bullets = bullets;
        this.bullets1 = bullets1;
        this.bullets2 = bullets2;
        this.enemies1 = enemies1;
        this.towers = towers;
        this.towers1 = towers1;
        this.towers2 = towers2;
        this.tile = tile;
        this.wait = wait;
        this.wait1 = wait1;
        this.wait2 = wait2;
        this.bosses=bosses;
    }
    public void addEnemy(){
        if(wait>100) {
            int random = rd.nextInt(2);
            if(random == 0) {
                enemies.add(new Enemy());
                temp++;
            }
            else {
                enemies1.add(new Enemy1());
                temp++;
            }

            wait = 0;
        }
        else
            wait++;
    }
    public void add(){
        if(wait1>5) {
            for (Tower tower:towers)
            {
                if(enemies.size()>0&&enemies1.size()>0) {
                        Enemy enemyG = enemies.get(0);
                        for (Enemy enemy : enemies) {
                            if (Math.abs(enemy.getX() - tower.getX()) < Math.abs(enemyG.getX() - tower.getX()) && Math.abs(enemy.getY() - tower.getY()) <= Math.abs(enemy.getY() - tower.getY())
                                    && Math.abs(enemy.getX() - tower.getX()) <= tower.getRange() && Math.abs(enemy.getY() - tower.getY()) <= tower.getRange())
                                enemyG = enemy;
                        }
                    Enemy1 enemyG1=enemies1.get(0);
                    for(Enemy1 enemy1: enemies1){
                        if(Math.abs(enemy1.getX()-tower.getX())<Math.abs(enemyG1.getX()-tower.getX()) &&Math.abs(enemy1.getY()-tower.getY())<=Math.abs(enemy1.getY()-tower.getY())
                                && Math.abs(enemy1.getX()-tower.getX())<=tower.getRange()&&Math.abs(enemy1.getY()-tower.getY())<=tower.getRange()) enemyG1 = enemy1;
                    }
                     if(Math.abs(enemyG.getX()-tower.getX())<=tower.getRange()&&Math.abs(enemyG.getY()-tower.getY())<=tower.getRange()) {
                         Bullet bullet = new Bullet(tower.getX() + 25, tower.getY() + 25, enemyG.getX(),
                                 enemyG.getY());
                         bullets.add(bullet);
                         wait1 = 0;
                     }
                     else if(Math.abs(enemyG1.getX()-tower.getX())<=tower.getRange()&&Math.abs(enemyG1.getY()-tower.getY())<=tower.getRange()) {
                         Bullet bullet = new Bullet(tower.getX() + 25, tower.getY() + 25, enemyG1.getX(),
                                 enemyG1.getY());
                         bullets.add(bullet);
                         wait1 = 0;
                     }
                }
                else if(enemies.size() > 0) {
                    Enemy enemyG = enemies.get(0);
                    for (Enemy enemy : enemies) {
                        if (Math.abs(enemy.getX() - tower.getX()) < Math.abs(enemyG.getX() - tower.getX()) && Math.abs(enemy.getY() - tower.getY()) <= Math.abs(enemy.getY() - tower.getY())
                                && Math.abs(enemy.getX() - tower.getX()) <= tower.getRange() && Math.abs(enemy.getY() - tower.getY()) <= tower.getRange())
                            enemyG = enemy;
                    }
                    if (Math.abs(enemyG.getX() - tower.getX()) <= tower.getRange() && Math.abs(enemyG.getY() - tower.getY()) <= tower.getRange()) {
                        Bullet bullet = new Bullet(tower.getX() + 25, tower.getY() + 25, enemyG.getX(),
                                enemyG.getY());
                        bullets.add(bullet);
                        wait1 = 0;
                    }
                }
                    else if(enemies1.size()>0){
                        Enemy1 enemyG1=enemies1.get(0);
                        for(Enemy1 enemy1: enemies1){
                            if(Math.abs(enemy1.getX()-tower.getX())<Math.abs(enemyG1.getX()-tower.getX()) &&Math.abs(enemy1.getY()-tower.getY())<=Math.abs(enemy1.getY()-tower.getY())
                                    && Math.abs(enemy1.getX()-tower.getX())<=tower.getRange()&&Math.abs(enemy1.getY()-tower.getY())<=tower.getRange()) enemyG1 = enemy1;
                        }
                        if(Math.abs(enemyG1.getX()-tower.getX())<=tower.getRange()&&Math.abs(enemyG1.getY()-tower.getY())<=tower.getRange()) {
                            Bullet bullet = new Bullet(tower.getX() + 25, tower.getY() + 25, enemyG1.getX(),
                                    enemyG1.getY());
                            bullets.add(bullet);
                            wait1 = 0;
                        }

                    }
                else if(bosses.size()>0){
                            if(Math.abs(bosses.get(0).getX()-tower.getX())<=tower.getRange()&&Math.abs(bosses.get(0).getY()-tower.getY())<=tower.getRange()) {
                                //System.out.println("xxx");
                                Bullet bullet = new Bullet(tower.getX() + 25, tower.getY() + 25, bosses.get(0).getX(),
                                        bosses.get(0).getY());
                                bullets.add(bullet);
                                wait1 = 0;
                            }
                }
            }
        }
        else
            wait1++;

        if(wait2>5) {
            for (Tower1 tower1:towers1)
            {
                if(enemies.size()>0&&enemies1.size()>0) {
                    Enemy enemyG=enemies.get(0);
                    for(Enemy enemy: enemies){
                        if(Math.abs(enemy.getX()-tower1.getX())<Math.abs(enemyG.getX()-tower1.getX()) &&Math.abs(enemy.getY()-tower1.getY())<=Math.abs(enemy.getY()-tower1.getY())
                                && Math.abs(enemy.getX()-tower1.getX())<=tower1.getRange()&&Math.abs(enemy.getY()-tower1.getY())<=tower1.getRange() ) enemyG = enemy;
                    }
                    Enemy1 enemyG1=enemies1.get(0);
                    for(Enemy1 enemy1: enemies1){
                        if(Math.abs(enemy1.getX()-tower1.getX())<Math.abs(enemyG1.getX()-tower1.getX()) &&Math.abs(enemy1.getY()-tower1.getY())<=Math.abs(enemy1.getY()-tower1.getY())
                                && Math.abs(enemy1.getX()-tower1.getX())<=tower1.getRange()&&Math.abs(enemy1.getY()-tower1.getY())<=tower1.getRange()) enemyG1 = enemy1;
                    }
                    if(Math.abs(enemyG.getX()-tower1.getX())<=tower1.getRange()&&Math.abs(enemyG.getY()-tower1.getY())<=tower1.getRange()) {
                        Bullet1 bullet1 = new Bullet1(tower1.getX() + 25, tower1.getY() + 25, enemyG.getX(),
                                enemyG.getY());
                        bullets1.add(bullet1);
                        wait2 = 0;
                    }
                    else if(Math.abs(enemyG1.getX()-tower1.getX())<=tower1.getRange()&&Math.abs(enemyG1.getY()-tower1.getY())<=tower1.getRange()) {
                        Bullet1 bullet1 = new Bullet1(tower1.getX() + 25, tower1.getY() + 25, enemyG1.getX(),
                                enemyG1.getY());
                        bullets1.add(bullet1);
                        wait2 = 0;
                    }
                }
                else if(enemies.size() > 0) {
                    Enemy enemyG = enemies.get(0);
                    for (Enemy enemy : enemies) {
                        if (Math.abs(enemy.getX() - tower1.getX()) < Math.abs(enemyG.getX() - tower1.getX()) && Math.abs(enemy.getY() - tower1.getY()) <= Math.abs(enemy.getY() - tower1.getY())
                                && Math.abs(enemy.getX() - tower1.getX()) <= tower1.getRange() && Math.abs(enemy.getY() - tower1.getY()) <= tower1.getRange())
                            enemyG = enemy;
                    }
                    if (Math.abs(enemyG.getX() - tower1.getX()) <= tower1.getRange() && Math.abs(enemyG.getY() - tower1.getY()) <= tower1.getRange()) {
                        Bullet1 bullet1 = new Bullet1(tower1.getX() + 25, tower1.getY() + 25, enemyG.getX(),
                                enemyG.getY());
                        bullets1.add(bullet1);
                        wait2 = 0;
                    }
                }
                else if(enemies1.size()>0){
                    Enemy1 enemyG1=enemies1.get(0);
                    for(Enemy1 enemy1: enemies1){
                        if(Math.abs(enemy1.getX()-tower1.getX())<Math.abs(enemyG1.getX()-tower1.getX()) &&Math.abs(enemy1.getY()-tower1.getY())<=Math.abs(enemy1.getY()-tower1.getY())
                                && Math.abs(enemy1.getX()-tower1.getX())<=tower1.getRange()&&Math.abs(enemy1.getY()-tower1.getY())<=tower1.getRange()) enemyG1 = enemy1;
                    }
                    if(Math.abs(enemyG1.getX()-tower1.getX())<=tower1.getRange()&&Math.abs(enemyG1.getY()-tower1.getY())<=tower1.getRange()) {
                        Bullet1 bullet1 = new Bullet1(tower1.getX() + 25, tower1.getY() + 25, enemyG1.getX(),
                                enemyG1.getY());
                        bullets1.add(bullet1);
                        wait2 = 0;
                    }

                }
                else if(bosses.size()>0){
                    if(Math.abs(bosses.get(0).getX()-tower1.getX())<=tower1.getRange()&&Math.abs(bosses.get(0).getY()-tower1.getY())<=tower1.getRange()) {
                        //System.out.println("xxx");
                        Bullet1 bullet1 = new Bullet1(tower1.getX() + 25, tower1.getY() + 25, bosses.get(0).getX(),
                                bosses.get(0).getY());
                        bullets1.add(bullet1);
                        wait2 = 0;
                    }
                }

            }
        }
        else
            wait2++;
        if(wait3>5) {
            for (Tower2 tower2:towers2)
            {
                if(enemies.size()>0&&enemies1.size()>0) {
                    Enemy enemyG=enemies.get(0);
                    for(Enemy enemy: enemies){
                        if(Math.abs(enemy.getX()-tower2.getX())<Math.abs(enemyG.getX()-tower2.getX()) &&Math.abs(enemy.getY()-tower2.getY())<=Math.abs(enemy.getY()-tower2.getY())
                                && Math.abs(enemy.getX()-tower2.getX())<=tower2.getRange()&&Math.abs(enemy.getY()-tower2.getY())<=tower2.getRange() ) enemyG = enemy;
                    }
                    Enemy1 enemyG1=enemies1.get(0);
                    for(Enemy1 enemy1: enemies1){
                        if(Math.abs(enemy1.getX()-tower2.getX())<Math.abs(enemyG1.getX()-tower2.getX()) &&Math.abs(enemy1.getY()-tower2.getY())<=Math.abs(enemy1.getY()-tower2.getY())
                                && Math.abs(enemy1.getX()-tower2.getX())<=tower2.getRange()&&Math.abs(enemy1.getY()-tower2.getY())<=tower2.getRange()) enemyG1 = enemy1;
                    }
                    if(Math.abs(enemyG.getX()-tower2.getX())<=tower2.getRange()&&Math.abs(enemyG.getY()-tower2.getY())<=tower2.getRange()) {
                        Bullet2 bullet2 = new Bullet2(tower2.getX() + 25, tower2.getY() + 25, enemyG.getX(),
                                enemyG.getY());
                        bullets2.add(bullet2);
                        wait3 = 0;
                    }
                    else if(Math.abs(enemyG1.getX()-tower2.getX())<=tower2.getRange()&&Math.abs(enemyG1.getY()-tower2.getY())<=tower2.getRange()) {
                        Bullet2 bullet2 = new Bullet2(tower2.getX() + 25, tower2.getY() + 25, enemyG1.getX(),
                                enemyG1.getY());
                        bullets2.add(bullet2);
                        wait3 = 0;
                    }
                }
                else if(enemies.size() > 0) {
                    Enemy enemyG = enemies.get(0);
                    for (Enemy enemy : enemies) {
                        if (Math.abs(enemy.getX() - tower2.getX()) < Math.abs(enemyG.getX() - tower2.getX()) && Math.abs(enemy.getY() - tower2.getY()) <= Math.abs(enemy.getY() - tower2.getY())
                                && Math.abs(enemy.getX() - tower2.getX()) <= tower2.getRange() && Math.abs(enemy.getY() - tower2.getY()) <= tower2.getRange())
                            enemyG = enemy;
                    }
                    if (Math.abs(enemyG.getX() - tower2.getX()) <= tower2.getRange() && Math.abs(enemyG.getY() - tower2.getY()) <= tower2.getRange()) {
                        Bullet2 bullet2 = new Bullet2(tower2.getX() + 25, tower2.getY() + 25, enemyG.getX(),
                                enemyG.getY());
                        bullets2.add(bullet2);
                        wait3 = 0;
                    }
                }
                else if(enemies1.size()>0){
                    Enemy1 enemyG1=enemies1.get(0);
                    for(Enemy1 enemy1: enemies1){
                        if(Math.abs(enemy1.getX()-tower2.getX())<Math.abs(enemyG1.getX()-tower2.getX()) &&Math.abs(enemy1.getY()-tower2.getY())<=Math.abs(enemy1.getY()-tower2.getY())
                                && Math.abs(enemy1.getX()-tower2.getX())<=tower2.getRange()&&Math.abs(enemy1.getY()-tower2.getY())<=tower2.getRange()) enemyG1 = enemy1;
                    }
                    if(Math.abs(enemyG1.getX()-tower2.getX())<=tower2.getRange()&&Math.abs(enemyG1.getY()-tower2.getY())<=tower2.getRange()) {
                        Bullet2 bullet2 = new Bullet2(tower2.getX() + 25, tower2.getY() + 25, enemyG1.getX(),
                                enemyG1.getY());
                        bullets2.add(bullet2);
                        wait3 = 0;
                    }

                }
                else if(bosses.size()>0){
                    if(Math.abs(bosses.get(0).getX()-tower2.getX())<=tower2.getRange()&&Math.abs(bosses.get(0).getY()-tower2.getY())<=tower2.getRange()) {
                        //System.out.println("xxx");
                        Bullet2 bullet2 = new Bullet2(tower2.getX() + 25, tower2.getY() + 25, bosses.get(0).getX(),
                                bosses.get(0).getY());
                        bullets2.add(bullet2);
                        wait3 = 0;
                    }
                }

            }
        }
        else
            wait3++;

    }
    public void move(){
        for(int i=0; i < bullets.size(); i++) {
            Bullet bullet = bullets.get(i);
            bullet.move();
            if(bullet.getY1() >= 600||bullet.getY1()<=0||bullet.getX1()>=1000||bullet.getX1()<=0) bullets.remove(i);
        }
        for(int i=0; i < bullets1.size(); i++) {
            Bullet1 bullet1 = bullets1.get(i);
            bullet1.move();
            if(bullet1.getY1() >= 600||bullet1.getY1()<=0||bullet1.getX1()>=1000||bullet1.getX1()<=0) bullets1.remove(i);
        }
        for(int i=0; i < bullets2.size(); i++) {
            Bullet2 bullet2 = bullets2.get(i);
            bullet2.move();
            if(bullet2.getY1() >= 600||bullet2.getY1()<=0||bullet2.getX1()>=1000||bullet2.getX1()<=0) bullets2.remove(i);
        }

        for(int i=0; i < enemies.size(); i++){
            Enemy enemy = enemies.get(i);
            enemy.move();
            if(enemy.getX()>=1000){
                enemies.remove(i);
                tile.setPlayerHp(tile.getPlayerHp()-10);
            }
        }
        for(int i=0; i < enemies1.size(); i++){
            Enemy1 enemy1 = enemies1.get(i);
            enemy1.move();
            if(enemy1.getX()>=1000){
                enemies1.remove(i);
                tile.setPlayerHp(tile.getPlayerHp()-10);
            }
        }

    }
}
