package TowerDefense.Solution;

import TowerDefense.Bullet.Bullet;
import TowerDefense.Bullet.Bullet1;
import TowerDefense.Bullet.Bullet2;
import TowerDefense.Enemy.Enemy;
import TowerDefense.Enemy.Enemy1;
import TowerDefense.Enemy.EnemyBoss;
import TowerDefense.Tile.Road;
import TowerDefense.Tile.Tile;
import TowerDefense.Tower.Tower;
import TowerDefense.Tower.Tower1;
import TowerDefense.Tile.gameOver;
import TowerDefense.Tower.Tower2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class GameField extends JPanel implements Runnable {


    private Image image;
    private int x, y, wait = 0, wait1=0,wait2=0,xa,ya,x1,y1,x2,y2,b=0;
    List<Enemy> enemies = new ArrayList<Enemy>();
    List<Enemy1> enemies1 = new ArrayList<Enemy1>();
    List<EnemyBoss> bosses = new ArrayList<EnemyBoss>() ;
    List<Bullet> bullets = new ArrayList<Bullet>();
    List<Bullet1> bullets1 = new ArrayList<Bullet1>();
    List<Tower> towers = new ArrayList<Tower>();
    List<Bullet2> bullets2 = new ArrayList<Bullet2>();
    List<Tower2> towers2 = new ArrayList<Tower2>();
    List<Tower1> towers1 = new ArrayList<Tower1>();
    gameOver gameOver ;
    Road r = new Road();
    Tile tile = new Tile();

    Impact impact = new Impact(enemies,enemies1,bosses,bullets,bullets1,bullets2,tile);

    Update update = new Update(enemies, bullets, bullets1,bullets2, enemies1, bosses, towers, towers1,towers2, tile, wait, wait1, wait2);

    public GameField(){
        enemies.add(new Enemy());
        enemies1.add(new Enemy1());
        for(Tower tower: towers)
        bullets.add(new Bullet(tower.getX(),tower.getY(),0,0));
        gameOver = new gameOver(tile);
        Thread thread = new Thread(this);
        thread.start();
        ImageIcon imageIcon = new ImageIcon("image/nen2.png");
        image = imageIcon.getImage();
        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent a) {
                super.mouseClicked(a);
                xa = (int) a.getPoint().getX();
                ya = (int) a.getPoint().getY();

                if (ya <= 170 && ya >= 110 && xa >= 1025 && xa <= 1085) {
                    System.out.println("clicked 1");

                    addMouseListener(new MouseAdapter() {
                        boolean added = false;
                        @Override
                        public void mouseClicked(MouseEvent e) {
                            super.mouseClicked(e);
                            if(added)
                                return;
                            x = (int) e.getPoint().getX();
                            y = (int) e.getPoint().getY();
                            System.out.println("clicked 12");
                            int temp = 0;
                            for (int i=0; i<towers.size(); i++) {
                                Tower tower = towers.get(i);
                                if (new Rectangle(x - 30, y - 30, 60, 60).intersects(new Rectangle(tower.getX(), tower.getY(), 60, 60))) {
                                    towers1.add(new Tower1(tower.getX(),tower.getY()));
                                    tile.setCoin(tile.getCoin()-tower.getCost()/2);
                                    towers.remove(tower);
                                    temp++;
                                }
                            }

                            for (Tower1 tower1 : towers1) {
                                if (new Rectangle(x - 30, y - 30, 60, 60).intersects(new Rectangle(tower1.getX(), tower1.getY(), 60, 60))) {
                                    temp++;
                                }
                            }
                            for (Tower2 tower2 : towers2) {
                                if (new Rectangle(x - 30, y - 30, 60, 60).intersects(new Rectangle(tower2.getX(), tower2.getY(), 60, 60))) {
                                    temp++;
                                }
                            }
                            Tower newTower = new Tower(x - 30, y - 30);
                            if (!newTower.asRoad(x - 30, y - 30) && tile.getCoin() >= 100 && temp == 0) {
                                towers.add(newTower);
                                tile.setCoin(tile.getCoin() - newTower.getCost());
                            }
                            added = true;
                        }
                    });
                }

                if (ya <= 280 && ya >= 210 && xa >= 1025 && xa <= 1085) {
                    System.out.println("clicked 2");
                    addMouseListener(new MouseAdapter() {
                        boolean added1 = false;
                        @Override
                        public void mouseClicked(MouseEvent e1) {
                            if(added1)
                                return;

                            super.mouseClicked(e1);
                            x1 = (int) e1.getPoint().getX();
                            y1 = (int) e1.getPoint().getY();
                            System.out.println("clicked 22");
                            int temp1 = 0;

                            try{
                                for (Tower1 tower1 : towers1) {
                                    if (new Rectangle(x1 - 30, y1 - 30, 60, 60).intersects(new Rectangle(tower1.getX(), tower1.getY(), 60, 60))) {
                                        towers2.add(new Tower2(tower1.getX(),tower1.getY()));
                                        tile.setCoin(tile.getCoin()-150);
                                        towers1.remove(tower1);
                                        temp1++;
                                    }
                                }
                            } catch (Exception e){}
                            for (Tower tower : towers) {
                                if (new Rectangle(x1 - 30, y1 - 30, 60, 60).intersects(new Rectangle(tower.getX(), tower.getY(), 60, 60))) {
                                    temp1++;
                                }
                            }
                            for (Tower2 tower2 : towers2) {
                                if (new Rectangle(x1 - 30, y1 - 30, 60, 60).intersects(new Rectangle(tower2.getX(), tower2.getY(), 60, 60))) {
                                    temp1++;
                                }
                            }
                            Tower1 newTower1 = new Tower1(x1 - 30, y1 - 30);
                            if (newTower1.asRoad(x1 - 30, y1 - 30) && tile.getCoin() >= 200 && temp1 == 0) {
                                towers1.add(newTower1);
                                tile.setCoin(tile.getCoin() - newTower1.getCost());
                            }
                            added1 = true;
                        }
                    });
                }
                if (ya <= 370 && ya >= 310 && xa >= 1025 && xa <= 1085) {
                    System.out.println("clicked 3");
                    addMouseListener(new MouseAdapter() {
                        boolean added2 = false;
                        @Override
                        public void mouseClicked(MouseEvent e2) {
                            if(added2)
                                return;

                            super.mouseClicked(e2);
                            x2 = (int) e2.getPoint().getX();
                            y2 = (int) e2.getPoint().getY();
                            System.out.println("clicked 33");
                            int temp2 = 0;

                            for (Tower1 tower1 : towers1) {
                                if (new Rectangle(x2 - 30, y2 - 30, 60, 60).intersects(new Rectangle(tower1.getX(), tower1.getY(), 60, 60))) {
                                    temp2++;
                                }
                            }
                            for (Tower tower : towers) {
                                if (new Rectangle(x2 - 30, y2 - 30, 60, 60).intersects(new Rectangle(tower.getX(), tower.getY(), 60, 60))) {
                                    temp2++;
                                }
                            }
                            for (Tower2 tower2 : towers2) {
                                if (new Rectangle(x2 - 30, y2 - 30, 60, 60).intersects(new Rectangle(tower2.getX(), tower2.getY(), 60, 60))) {
                                    temp2++;
                                }
                            }
                            Tower2 newTower2 = new Tower2(x2 - 30, y2 - 30);
                            if (newTower2.asRoad(x2 - 30, y2 - 30) && tile.getCoin() >= 300 && temp2 == 0) {
                                towers2.add(newTower2);
                                tile.setCoin(tile.getCoin() - newTower2.getCost());
                            }
                            added2 = true;
                        }
                    });
                }

            }
        });



    }
    public void paint(Graphics g){
        g.drawImage(image,0,0,this);
        r.paint(g);

        for(Enemy enemy: enemies) {
            enemy.paint(g);
        }
        for(Enemy1 enemy1: enemies1) {
            enemy1.paint(g);
        }
        if(bosses.size()>0)bosses.get(0).paint(g);

        try{
            for(Bullet bullet: bullets)
                bullet.paint(g);
        } catch (Exception e){}
        try{
            for(Bullet1 bullet1: bullets1)
                bullet1.paint(g);
        } catch (Exception e){}
        try{
            for(Bullet2 bullet2: bullets2)
                bullet2.paint(g);
        } catch (Exception e){}
        for(Tower1 tower1: towers1)
            tower1.paint(g);
        for(Tower tower: towers)
            tower.paint(g);
        for(Tower2 tower2: towers2)
            tower2.paint(g);
        tile.paint(g);

        if(tile.getPlayerHp()<=0||bosses.size()>0&&bosses.get(0).getX()>=1000){
            gameOver.paint1(g);
        }
        if(impact.isWin()){
            gameOver.paint2(g);
        }

    }
    @Override
    public void run() {
        while (true){
            repaint();
            if( b==0&&enemies.size()==0&&enemies1.size()==0) {
                bosses.add(new EnemyBoss());
                System.out.println("aaa");
               b=1;
            }
            if(update.getTemp()<=30) update.addEnemy();
            update.add();
            update.move();
            if(bosses.size()>0){
                bosses.get(0).move();
            }
            impact.checkImpact();
            impact.checkImpact1();
            impact.checkImpact2();
            if(tile.getPlayerHp()<=0) break;
            if(impact.isWin()) break;
            if(bosses.size()>0&&bosses.get(0).getX()>=1000){
                break;
            }

            try {
                Thread.sleep(15);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }

}
