package TowerDefense.Tile;

import javax.swing.*;
import java.awt.*;

public class Tile extends JPanel {
    private Image image,money,tower,tower1,tower2,player;
    private int coin =600;
    private int playerHp = 80;
    private int score = 0;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getPlayerHp() {
        return playerHp;
    }

    public void setPlayerHp(int playerHp) {
        this.playerHp = playerHp;
    }

    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }

    public Tile(){
        ImageIcon imageIcon = new ImageIcon("image/tile.png");
        image = imageIcon.getImage();
        ImageIcon imageIcon1 = new ImageIcon("image/x.png");
        money = imageIcon1.getImage();
        ImageIcon imageIcon2 = new ImageIcon("image/tru1.png");
        tower = imageIcon2.getImage();
        ImageIcon imageIcon3 = new ImageIcon("image/tru2.png");
        tower1 = imageIcon3.getImage();
        ImageIcon imageIcon5 = new ImageIcon("image/tru3.png");
        tower2 = imageIcon5.getImage();
        ImageIcon imageIcon4 = new ImageIcon("image/boy.png");
        player = imageIcon4.getImage();
    }
    public void paint(Graphics g){
        g.drawImage(image,1000,0,this);
        g.drawImage(money,1025,30,this);
        g.drawImage(tower,1025,110,this);
        g.drawImage(tower1,1025,210,this);
        g.drawImage(tower2,1025,310,this);
        g.drawImage(player,1015,420,this);
        g.setColor(Color.YELLOW);
        g.setFont( new Font("Arial",Font.BOLD,14));
        g.drawString(coin+"$",1040,100);
        g.drawString("100$",1040,190);
        g.drawString("200$",1040,290);
        g.drawString("300$",1040,390);
        g.setColor(Color.RED);
        g.fillRect(1010,500,playerHp,20);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD,20));
        g.drawString("SCORE:",1020,550);
        g.setFont(new Font("Arial",Font.BOLD,20));
        g.drawString(String.valueOf(score),1040,580);
    }
}
