package TowerDefense.Tile;

import javax.swing.*;
import java.awt.*;

public class gameOver extends JPanel {
    Tile tile = new Tile();
    private Image image,image1;
    private int x=250,y=150;
    public gameOver(Tile tile) {
        ImageIcon imageIcon = new ImageIcon("image/gameover.png");
        image = imageIcon.getImage();
        ImageIcon imageIcon1 = new ImageIcon("image/win.jpg");
        image1 = imageIcon1.getImage();
        this.tile = tile;
    }
    public void paint1(Graphics g){
        g.drawImage(image,x,y,  this);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD,50));
        g.drawString("SCORE:"+"  "+tile.getScore(),380,100);
    }
    public void paint2(Graphics g)
    {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD,50));
        g.drawString("SCORE:"+" "+tile.getScore(),380,100);
        g.drawImage(image1,x,y,  this);
    }
}
