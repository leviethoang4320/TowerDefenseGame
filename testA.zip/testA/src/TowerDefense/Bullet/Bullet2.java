package TowerDefense.Bullet;

import java.awt.*;

public class Bullet2 extends BulletOrigin {
    public Bullet2(int x, int y, int xE, int yE) {
        super(x, y, xE, yE);
        DAMAGE = 3;
    }
    public void paint(Graphics g){
        g.setColor(Color.WHITE);
        g.fillOval(x, y, 15, 15);
    }
}
