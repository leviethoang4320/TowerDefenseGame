package TowerDefense.Bullet;

import java.awt.*;

public class Bullet1 extends BulletOrigin{

    public Bullet1(int x, int y, int xE, int yE) {
        super(x, y, xE, yE);
        DAMAGE =2;
    }
    public void paint(Graphics g){
        g.setColor(Color.ORANGE);
        g.fillRect(x, y, 10, 10);
    }
}