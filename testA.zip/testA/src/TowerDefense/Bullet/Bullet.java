package TowerDefense.Bullet;

import java.awt.*;

public class Bullet extends BulletOrigin{

    public Bullet(int x, int y, int xE, int yE) {
        super(x, y, xE, yE);
        DAMAGE =1;
    }
    public void paint(Graphics g){
        g.setColor(Color.CYAN);
        g.fillOval(x, y, 10, 10);
    }
}