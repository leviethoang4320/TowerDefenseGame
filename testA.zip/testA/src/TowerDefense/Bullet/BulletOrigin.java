package TowerDefense.Bullet;

import javax.swing.*;
import java.awt.*;

public class BulletOrigin extends JPanel {
    protected int x;
    protected int y;
    protected int xStop;
    protected int yStop;

    protected int DAMAGE ;
    public int getDAMAGE (){
        return this.DAMAGE;
    }

    public BulletOrigin(int x, int y, int xE,int yE) {
        this.x = x;
        this.y = y;
        xStop = x + (xE - x) * 120;
        yStop = y + (yE - y) * 120;
    }


    public  int getX1() {
        return x;
    }


    public int getY1() {
        return y;
    }


    public void move() {
        int d = (int) Math.sqrt( Math.pow(xStop - x, 2) + Math.pow(yStop - y, 2));
        x += 15* (xStop-x)/d;
        y += 15* (yStop-y)/d;
    }
}
