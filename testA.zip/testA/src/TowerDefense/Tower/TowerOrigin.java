package TowerDefense.Tower;

import javax.swing.*;
import java.awt.*;

public class TowerOrigin extends JPanel {
        private int x ;
        private int y;
        protected int cost , range;
        public int getCost() {
            return cost;
        }

    public int getRange() {
        return range;
    }

    @Override
        public int getX() {
            return x;
        }

        @Override
        public int getY() {
            return y;
        }


        public TowerOrigin(int x, int y){

            this.x = x;
            this.y = y;
        }



        public boolean R1(int x, int y){
            if(x>0&&x<900&&y>20&&y<130) return false;
            return true;
        }
        public boolean R2(int x, int y){
            if(x>790&&x<900&&y>130&&y<280) return false;
            return true;
        }
        public boolean R3(int x, int y){
            if(x>230&&x<840&&y>170&&y<280) return false;
            return true;
        }
        public boolean R4(int x, int y){
            if(x>230&&x<340&&y>290&&y<380) return false;
            return true;
        }
        public boolean R5(int x, int y){
            if(x>50&&x<340&&y>270&&y<380) return false;
            return true;
        }
        public boolean R6(int x, int y){
            if(x>50&&x<160&&y>380&&y<540) return false;
            return  true;
        }
        public boolean R7(int x, int y){
            if(x>110&&x<900&&y>430&&y<540) return false;
            return true;
        }
        public boolean RX(int x, int y){
            if(x>950||y>550) return false;
            return true;
        }
        public boolean asRoad(int x, int y){
            if(R1(x,y)&&R2(x,y)&&R3(x,y)&&R4(x,y)&&R5(x,y)&&R6(x,y)&&R7(x,y)&&RX(x,y)) return false;

            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(550,350,60,60))) return false;
            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(400,540,60,60))) return false;
            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(700,540,60,60))) return false;
            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(850,350,60,60))) return false;
            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(20,200,60,60))) return false;
            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(500,5,60,60))) return false;
            else if(new Rectangle(x,y,60,60).intersects(new Rectangle(900,5,60,60))) return false;
            return true;
        }

    }
