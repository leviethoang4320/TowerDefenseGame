package TowerDefense.Tower;

import javax.swing.*;
import java.awt.*;

public class Tower1 extends TowerOrigin{

       Image image;
    private int x,y;

    public Tower1(int x, int y) {
        super(x, y);
        this.x=x;
        this.y=y;
        cost = 200;
        range = 150;
        ImageIcon imageIcon = new ImageIcon("image/tru2.png");
        image = imageIcon.getImage();
    }
    public void paint(Graphics g){
        g.drawImage(image,x,y,this);
    }

}