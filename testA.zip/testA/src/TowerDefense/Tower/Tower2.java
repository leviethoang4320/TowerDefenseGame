package TowerDefense.Tower;

import javax.swing.*;
import java.awt.*;

public class Tower2 extends TowerOrigin {

    Image image;
    private int x,y;

    public Tower2(int x, int y) {
        super(x, y);
        this.x=x;
        this.y=y;
        cost = 300;
        range = 200;
        ImageIcon imageIcon = new ImageIcon("image/tru3.png");
        image = imageIcon.getImage();
    }
    public void paint(Graphics g){
        g.drawImage(image,x,y,this);
    }

}
