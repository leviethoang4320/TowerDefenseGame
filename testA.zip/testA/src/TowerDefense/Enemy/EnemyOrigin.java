
package TowerDefense.Enemy;

import javax.swing.*;

public class EnemyOrigin extends JPanel {
    protected int x = 0, y=80;
    protected int hp ;

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }


    public boolean X1(){
        if( y == 80 && x < 850) return true;
        else return false;
    }
    public boolean Y1(){
        if(y<230)
            return true;
        return false;
    }
    public boolean X2(){
        if(y>=230&&y<490&&x>290)
            return true;
        return false;
    }
    public boolean Y2(){
        if(x<=290&&y>=230&&y<330)
            return true;
        return false;
    }
    public boolean X3(){
        if(x<=290&&y>=330&&x>110&&y<490)
            return true;
        return false;
    }
    public boolean Y3(){
        if(x<=110&&y>=330&&y<490)
            return true;
        return false;
    }
    public boolean X4(){
        if(y>=490)
            return true;
        return false;
    }
    public void upX(){
        x+=2;
    }
    public void downX(){
        x-=2;
    }
    public void upY(){
        y+=2;

    }
    public void move(){
        if (X1()) {
            upX();
        } else if (Y1()) upY();
        else if (X2()) downX();
        else if (Y2()) upY();
        else if (X3()) downX();
        else if (Y3()) upY();
        else if (X4()) upX();
    }
}

