package TowerDefense.Enemy;

import javax.swing.*;
import java.awt.*;

public class Enemy1 extends EnemyOrigin {
    public Image image,image1,image2;
    public Enemy1(){
        ImageIcon imageIcon = new ImageIcon("image/tank21.png");
        image = imageIcon.getImage();
        ImageIcon imageIcon1 = new ImageIcon("image/tank22.png");
        image1 = imageIcon1.getImage();
        ImageIcon imageIcon2 = new ImageIcon("image/tank23.png");
        image2 = imageIcon2.getImage();
        hp = 40;
    }


    public void paint(Graphics g)
    {
        g.setColor(Color.RED);
        g.fillRect(x,y-5,hp,3);
        if (y == 80 && x < 850 || y >= 490)
            g.drawImage(image, x, y, this);
        else if (y >= 230 && x > 290 || x <= 290 && y >= 330 && x > 110 && y < 490)
            g.drawImage(image2, x, y, this);
        else
            g.drawImage(image1, x, y, this);
    }

}

