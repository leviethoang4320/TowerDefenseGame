package TowerDefense.Enemy;

import javax.swing.*;
import java.awt.*;

public class Enemy extends EnemyOrigin {
    //private int x = 0, y=85,hp=30;
    public Image image,image1,image2;
    public Enemy(){
        ImageIcon imageIcon = new ImageIcon("image/tank2.png");
        image = imageIcon.getImage();
        ImageIcon imageIcon1 = new ImageIcon("image/tank3.png");
        image1 = imageIcon1.getImage();
        ImageIcon imageIcon2 = new ImageIcon("image/tank4.png");
        image2 = imageIcon2.getImage();
        hp = 30;
    }


    public void paint(Graphics g)
    {
        g.setColor(Color.RED);
        g.fillRect(x,y-5,hp,3);
        if (y == 80 && x < 850 || y >= 490)
            g.drawImage(image, x, y, this);
        else if (y >= 230 && x > 290 || x <= 290 && y >= 330 && x > 110 && y < 490)
            g.drawImage(image2, x, y, this);
        else
            g.drawImage(image1, x, y, this);
    }

}
